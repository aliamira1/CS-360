package com.zybooks.theinventoryapp20;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {
    InventoryDatabaseHelper db;
    RecyclerView recyclerView;
    InventoryAdapter inventoryAdapter;
    List<InventoryItem> inventoryList;

    Button addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        Toolbar myToolbar = findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);

        db = new InventoryDatabaseHelper(this);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadData();

        inventoryAdapter = new InventoryAdapter(inventoryList);
        recyclerView.setAdapter(inventoryAdapter);

        addButton = findViewById(R.id.addButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddItemDialog();
            }
        });
    }

    private void loadData() {
        inventoryList = new ArrayList<>();
        Cursor cursor = db.getAllItems();
        if (cursor.moveToFirst()) {
            do {
                int idIndex = cursor.getColumnIndex(InventoryDatabaseHelper.COL_ITEM_ID);
                int nameIndex = cursor.getColumnIndex(InventoryDatabaseHelper.COL_ITEM_NAME);
                int quantityIndex = cursor.getColumnIndex(InventoryDatabaseHelper.COL_ITEM_QUANTITY);

                if (idIndex != -1 && nameIndex != -1 && quantityIndex != -1) {
                    int id = cursor.getInt(idIndex);
                    String name = cursor.getString(nameIndex);
                    int quantity = cursor.getInt(quantityIndex);
                    inventoryList.add(new InventoryItem(id, name, quantity));
                } else {
                    throw new RuntimeException("Column not found in cursor.");
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Item");

        View viewInflated = LayoutInflater.from(this).inflate(R.layout.dialog_add_item, null);
        builder.setView(viewInflated);

        final EditText itemInput = viewInflated.findViewById(R.id.itemNameInput);
        final EditText quantityInput = viewInflated.findViewById(R.id.itemQuantityInput);

        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String name = itemInput.getText().toString();
                int quantity = Integer.parseInt(quantityInput.getText().toString());
                if (!name.isEmpty() && quantity > 0) {
                    if (db.insertItem(name, quantity)) {
                        Toast.makeText(InventoryActivity.this, "Item added", Toast.LENGTH_SHORT).show();
                        loadData();  // Reload data from database
                        inventoryAdapter.notifyDataSetChanged();  // Notify adapter that data has changed
                    } else {
                        Toast.makeText(InventoryActivity.this, "Error adding item", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(InventoryActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.alert) {
            Intent intent = new Intent(InventoryActivity.this, ZeroQuantityActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
