package com.zybooks.theinventoryapp20;

import android.database.Cursor;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class ZeroQuantityActivity extends AppCompatActivity {
    InventoryDatabaseHelper db;
    RecyclerView recyclerView;
    InventoryAdapter inventoryAdapter;
    List<InventoryItem> inventoryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zero_quantity);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        db = new InventoryDatabaseHelper(this);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadData();

        inventoryAdapter = new InventoryAdapter(inventoryList);
        recyclerView.setAdapter(inventoryAdapter);
    }

    private void loadData() {
        inventoryList = new ArrayList<>();
        Cursor cursor = db.getZeroQuantityItems();
        if (cursor.moveToFirst()) {
            do {
                int idIndex = cursor.getColumnIndex(InventoryDatabaseHelper.COL_ITEM_ID);
                int nameIndex = cursor.getColumnIndex(InventoryDatabaseHelper.COL_ITEM_NAME);
                int quantityIndex = cursor.getColumnIndex(InventoryDatabaseHelper.COL_ITEM_QUANTITY);

                if (idIndex != -1 && nameIndex != -1 && quantityIndex != -1) {
                    int id = cursor.getInt(idIndex);
                    String name = cursor.getString(nameIndex);
                    int quantity = cursor.getInt(quantityIndex);
                    inventoryList.add(new InventoryItem(id, name, quantity));
                } else {
                    throw new RuntimeException("Column not found in cursor.");
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
    }
}
